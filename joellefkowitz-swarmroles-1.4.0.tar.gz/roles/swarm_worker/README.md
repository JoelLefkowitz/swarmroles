# Swarm worker

Joins a docker swarm as a worker

## Extends

* docker

## Variables

* swarm_join_addr
* swarm_worker_token
