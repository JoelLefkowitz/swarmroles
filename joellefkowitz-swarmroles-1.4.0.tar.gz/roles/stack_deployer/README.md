# Stack deployer

Deploys a stack to a docker swarm

## Extends

* docker

## Variables

* deploy_dir (Defaults to 'deploy')
* compose_file
* env_files (List of strings)
* stack_name
