# Base

Installs python and setuptools
