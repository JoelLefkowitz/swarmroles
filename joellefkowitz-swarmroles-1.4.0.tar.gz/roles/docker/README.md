# Docker

Installs the docker engine for Ubuntu

## Extends

* base
