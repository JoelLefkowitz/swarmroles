# Swarm initiator

Initialises a docker swarm

## Extends

* docker

## Sets facts

* swarm_join_addr
* swarm_manager_token
* swarm_worker_token
